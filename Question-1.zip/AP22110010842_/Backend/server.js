const http = require("http");

// Create the server
const server = http.createServer((req, res) => {
    if (req.method === "POST" && req.url === "/calculate") {
        let body = "";

        // Read incoming data
        req.on("data", chunk => {
            body += chunk.toString();
        });

        req.on("end", () => {
            try {
                const { num1, num2, operation } = JSON.parse(body);

                if (typeof num1 !== "number" || typeof num2 !== "number") {
                    res.writeHead(400, { "Content-Type": "application/json" });
                    return res.end(JSON.stringify({ error: "num1 and num2 must be numbers" }));
                }

                let result;
                switch (operation) {
                    case "add":
                        result = num1 + num2;
                        break;
                    case "subtract":
                        result = num1 - num2;
                        break;
                    case "multiply":
                        result = num1 * num2;
                        break;
                    case "divide":
                        if (num2 === 0) {
                            res.writeHead(400, { "Content-Type": "application/json" });
                            return res.end(JSON.stringify({ error: "Cannot divide by zero" }));
                        }
                        result = num1 / num2;
                        break;
                    default:
                        res.writeHead(400, { "Content-Type": "application/json" });
                        return res.end(JSON.stringify({ error: "Invalid operation. Use add, subtract, multiply, or divide." }));
                }

                res.writeHead(200, { "Content-Type": "application/json" });
                res.end(JSON.stringify({ num1, num2, operation, result }));
            } catch (error) {
                res.writeHead(400, { "Content-Type": "application/json" });
                res.end(JSON.stringify({ error: "Invalid JSON format" }));
            }
        });
    } else {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Not Found" }));
    }
});

// Start the server
const PORT = 5000;
server.listen(PORT, () => console.log(`Calculator API running on http://localhost:${PORT}`));
